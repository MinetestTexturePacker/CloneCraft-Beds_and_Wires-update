Minetest 0.4 mod: boats
=======================
by PilzAdam

License of source code:
-----------------------
WTFPL

License of media (textures and sounds):
---------------------------------------
WTFPL

Authors of media files:
-----------------------
textures: Zeg9
model: thetoon and Zeg9
