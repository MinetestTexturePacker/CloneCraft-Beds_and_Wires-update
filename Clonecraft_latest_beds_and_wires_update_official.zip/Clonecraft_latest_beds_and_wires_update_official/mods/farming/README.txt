Minetest Farming Redo Mod
by TenPlus1

based on

Minetest 0.4 mod: farming
=========================

License of source code:
-----------------------
Copyright (C) 2012-2013 PilzAdam

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO. 

License of media (textures):
----------------------------
Created by PilzAdam (License: WTFPL):
  farming_bread.png
  farming_soil.png
  farming_soil_wet.png
  farming_soil_wet_side.png
  farming_string.png

Created by Calinou (License: CC BY-SA):
  farming_tool_bronzehoe.png
  farming_tool_steelhoe.png
  farming_tool_stonehoe.png
  farming_tool_woodhoe.png
  farming_tool_mesehoe.png
  farming_tool_diamondhoe.png

Created by VanessaE (License: WTFPL):
  farming_cotton_seed.png
  farming_wheat_seed.png
  farming_flour.png
  farming_wheat.png
  farming_wheat_1.png
  farming_wheat_2.png
  farming_wheat_3.png
  farming_wheat_4.png
  farming_wheat_5.png
  farming_wheat_5.png
  farming_wheat_7.png
  farming_wheat_8.png
  farming_cotton_1.png
  farming_cotton_2.png
  farming_cotton_3.png
  farming_cotton_4.png
  farming_cotton_5.png
  farming_cotton_6.png
  farming_cotton_7.png
  farming_cotton_8.png

Created by Doc (License: WTFPL):
  farming_cucumber.png
  farming_cucumber_1.png
  farming_cucumber_2.png
  farming_cucumber_3.png
  farming_cucumber_4.png
  farming_potato.png
  farming_potato_1.png
  farming_potato_2.png
  farming_potato_3.png
  farming_potato_4.png
  farming_raspberries.png
  farming_raspberry_1.png
  farming_raspberry_2.png
  farming_raspberry_3.png
  farming_raspberry_4.png

Created by Gambit:
  default_junglegrass.png
  farming_carrot.png
  farming_carrot_1.png
  farming_carrot_2.png
  farming_carrot_3.png
  farming_carrot_4.png
  farming_carrot_5.png
  farming_carrot_6.png
  farming_carrot_7.png
  farming_carrot_8.png

Created by JoseTheCrafter and edited by TenPlus1:
  farming_tomato.png
  farming_tomato_1.png
  farming_tomato_2.png
  farming_tomato_3.png
  farming_tomato_4.png
  farming_tomato_5.png
  farming_tomato_6.png
  farming_tomato_7.png
  farming_tomato_8.png

Created by GeMinecraft and edited by TenPlus1:
  farming_corn.png
  farming_corn_cob.png
  farming_corn_1.png
  farming_corn_2.png
  farming_corn_3.png
  farming_corn_4.png
  farming_corn_5.png
  farming_corn_6.png
  farming_corn_7.png
  farming_corn_8.png

Created by TenPlus1
  farming_cocoa_1.png
  farming_cocoa_2.png
  farming_cocoa_3.png
  farming_cocoa_beans.png
  farming_cookie.png
  farming_raspberry_smoothie.png
  farming_rhubarb_1.png
  farming_rhubarb_2.png
  farming_rhubarb_3.png
  farming_rhubarb.png
  farming_rhubarb_pie.png