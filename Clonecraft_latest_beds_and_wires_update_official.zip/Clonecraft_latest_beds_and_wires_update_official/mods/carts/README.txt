Minetest 0.4 mod: carts
=======================
by PilzAdam
This version is modified by Kilarin (Donald Hines), all changes CC-0
modifications include:
  New Controls:LEFT or RIGHT to switch track at junction
               DOWN for hand break
               JUMP lock the users view to the view of the cart
               SNEAK unlock the users view from the cart
  Touring Rails: Try to maintain a speed of 4.5
  Chat notification of controls when cart is placed
  Track rail count in debug.txt  
  punch by driver patch from spillz
  get_voxel when hit ignore patch by minermoder27  

License of source code:
-----------------------
WTFPL

License of media (textures, sounds and models):
-----------------------------------------------
CC-0

Authors of media files:
-----------------------
kddekadenz:
  cart_bottom.png
  cart_side.png
  cart_top.png

Zeg9:
  cart.x
  cart.png

rarkenin:
  cart_rail_*.png
